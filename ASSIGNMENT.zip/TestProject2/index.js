import fetch from 'node-fetch';

// This code sample uses the 'node-fetch' library:
// https://www.npmjs.com/package/node-fetch


fetch('https://gauthammoluguru7.atlassian.net/rest/api/3/project/search', {
  method: 'GET',
  headers: {
    'Authorization': `Basic ${Buffer.from(
      'gauthammoluguru7@gmail.com:ATATT3xFfGF0TX7Ke0LvJZtUhXTFyxCdS0rJiOuOeiOMkMxh9bftiFvccv4PETA1-IC4bNR2d0eItVICwsmWH4lcyvTW93W4H_3n_oubE8vz0zZXkByPdE-bh4_SOnHjKQsknHg-7FTYpfbbyzwTFkWhIp7Z7ejgROXkwl5wpOFLjL6ciorhjEQ=7D7F7CCE'
    ).toString('base64')}`,
    'Accept': 'application/json'
  }
})
  .then(response => {
    if (response.status === 200) {
        console.log(response.status);
        
        return response.json();
    }
    else {
        console.log(`ERROR! Status code: ${response.status}`);
    }
  })
  .then(project => {
    console.log(project);
    let arr = project.values;
    arr.forEach(arr => {
        console.log(arr.name);
    });
  })
  .catch(err => console.error(err));
