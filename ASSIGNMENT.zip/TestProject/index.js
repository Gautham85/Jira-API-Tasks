// This code sample uses the 'node-fetch' library:
// https://www.npmjs.com/package/node-fetch
// const fetch = require('node-fetch');
import fetch from 'node-fetch';

// This code sample uses the 'node-fetch' library:
// https://www.npmjs.com/package/node-fetch
// const fetch = require('node-fetch');
const APIKEY = prompt('Enter your project key');


fetch(`https://gauthammoluguru7.atlassian.net/rest/api/3/project/${APIKEY}`, {
  method: 'GET',
  headers: {
    'Authorization': `Basic ${Buffer.from(
      'gauthammoluguru7@gmail.com:ATATT3xFfGF0TX7Ke0LvJZtUhXTFyxCdS0rJiOuOeiOMkMxh9bftiFvccv4PETA1-IC4bNR2d0eItVICwsmWH4lcyvTW93W4H_3n_oubE8vz0zZXkByPdE-bh4_SOnHjKQsknHg-7FTYpfbbyzwTFkWhIp7Z7ejgROXkwl5wpOFLjL6ciorhjEQ=7D7F7CCE'
    ).toString('base64')}`,
    'Accept': 'application/json'
  }
})
  .then(response => {
    if (response.status === 200) {
        console.log(response.status)
        return response.json();
    }
    else {
        console.log(`Failed to retreive project name Status: ${response.status}`);
    }
  })
  .then(projectDetails =>{
    const projectName  = projectDetails.name;
    const Issues = projectDetails.issueTypes;
    console.log(projectDetails);
    console.log(Issues.name);
    console.log(`Project name is ${projectDetails.name}`);
  })
  .catch(err => console.error(err));


 
